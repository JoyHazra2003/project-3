var counter=2
setInterval( function(){counter++;document.title=counter+" notifications";},1000);